﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class LightData
{
    public float[] color;
    public float[,] pastColors;

    public LightData(TimedLight _light)
    {
        color = new float[4];
        Color objectColor = _light.GetComponent<Renderer>().material.color;
        color[0] = objectColor.r;
        color[1] = objectColor.g;
        color[2] = objectColor.b;
        color[3] = objectColor.a;

        pastColors = new float[_light.pointsInTime.Count, 4];
        for (int i = 0; i < _light.pointsInTime.Count; i++)
        {
            Color colorInTime = _light.pointsInTime[i].color;
            pastColors[i, 0] = colorInTime.r;
            pastColors[i, 1] = colorInTime.g;
            pastColors[i, 2] = colorInTime.b;
            pastColors[i, 3] = colorInTime.a;
        }

        Debug.Log(pastColors.GetLength(0) + " colors");
        for (int i = 0; i < pastColors.GetLength(0); i++)
        {
            Debug.Log(pastColors[i, 0] + ", " + pastColors[i, 1] + ", " + pastColors[i, 2]);
        }
    }
}
