﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public float[] position;
    public float[] rotation;
    public float[,] pastPositions;
    public float[,] pastRotations;

    public PlayerData(TimedPlayer _player)
    {
        position = new float[3];
        position[0] = _player.transform.position.x;
        position[1] = _player.transform.position.y;
        position[2] = _player.transform.position.z;

        rotation = new float[4];
        rotation[0] = _player.transform.rotation.x;
        rotation[1] = _player.transform.rotation.y;
        rotation[2] = _player.transform.rotation.z;
        rotation[3] = _player.transform.rotation.w;

        pastPositions = new float[_player.pointsInTime.Count, 3];
        pastRotations = new float[_player.pointsInTime.Count, 4];
        for (int i = 0; i < _player.pointsInTime.Count; i++)
        {
            Vector3 positionInTime = _player.pointsInTime[i].position;
            pastPositions[i, 0] = positionInTime.x;
            pastPositions[i, 1] = positionInTime.y;
            pastPositions[i, 2] = positionInTime.z;

            Quaternion rotationInTime = _player.pointsInTime[i].rotation;
            pastRotations[i, 0] = rotationInTime.x;
            pastRotations[i, 1] = rotationInTime.y;
            pastRotations[i, 2] = rotationInTime.z;
            pastRotations[i, 3] = rotationInTime.w;
        }

        Debug.Log(pastPositions.GetLength(0) + " positions");
        for(int i = 0; i < pastPositions.GetLength(0); i++)
        {
            Debug.Log(pastPositions[i, 0] + ", " + pastPositions[i, 1] + ", " + pastPositions[i, 2]);
        }
    }
}
