﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveManager : MonoBehaviour
{
    public TimedPlayer player;
    public TimedLight light; 


    public void SavePlayer()
    {
        SaveSystem.SavePlayer(player);
    }

    public void SaveLight()
    {
        SaveSystem.SaveLight(light);
    }

    public void LoadPlayer()
    {
        PlayerData data = SaveSystem.LoadPlayer();

        player.transform.position = new Vector3(data.position[0], data.position[1], data.position[2]);
        player.transform.rotation = new Quaternion(data.rotation[0], data.rotation[1], data.rotation[2], data.rotation[3]);

        List<PlayerPointInTime> pointsInTime = new List<PlayerPointInTime>();
        Debug.Log(data.pastPositions.GetLength(0) == data.pastRotations.GetLength(0));
        for(int i = 0; i < data.pastPositions.GetLength(0); i++)
        {
            PlayerPointInTime point = new PlayerPointInTime(new Vector3(data.pastPositions[i, 0], data.pastPositions[i, 1], data.pastPositions[i, 2]), new Quaternion(data.pastRotations[i, 0], data.pastRotations[i, 1], data.pastRotations[i, 2], data.pastRotations[i, 3]));
            pointsInTime.Add(point);
            Debug.Log(point.position);
        }
        player.pointsInTime = pointsInTime;
    }

    public void LoadLight()
    {
        LightData data = SaveSystem.LoadLight();

        light.GetComponent<Renderer>().material.color = new Color(data.color[0], data.color[1], data.color[2]);

        List<LightPointInTime> pointsInTime = new List<LightPointInTime>();
        Debug.Log(data.color.GetLength(0) == data.pastColors.GetLength(0));
        for (int i = 0; i < data.pastColors.GetLength(0); i++)
        {
            LightPointInTime point = new LightPointInTime(new Color(data.pastColors[i, 0], data.pastColors[i, 1], data.pastColors[i, 2], data.pastColors[i, 3]));
            pointsInTime.Add(point);
            Debug.Log(point.color);
        }
        light.pointsInTime = pointsInTime;
    }
}
