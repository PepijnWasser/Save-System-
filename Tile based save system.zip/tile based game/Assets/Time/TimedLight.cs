﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimedLight : TimedObject
{
    public List<LightPointInTime> pointsInTime = new List<LightPointInTime>();

    private void Start()
    {
        ChangeColor.onChangingColor += AddPointInTime;
    }

    private void OnDestroy()
    {
        ChangeColor.onChangingColor -= AddPointInTime;
    }

    public override void ReverseTime()
    {
        if (pointsInTime.Count > 0)
        {
            GetComponent<Renderer>().material.color = pointsInTime[pointsInTime.Count - 1].color;
            pointsInTime.RemoveAt(pointsInTime.Count - 1);
        }
    }

    public void AddPointInTime()
    {
        pointsInTime.Add(new LightPointInTime(GetComponent<Renderer>().material.color));
    }
}
