﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightPointInTime
{
    public Color color;

    public LightPointInTime(Color _color)
    {
        color = _color;
    }
}
