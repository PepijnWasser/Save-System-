﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimedPlayer : TimedObject
{
    public List<PlayerPointInTime> pointsInTime = new List<PlayerPointInTime>();

    private void Start()
    {
        movement.onMoving += AddPointInTime;
    }

    private void OnDestroy()
    {
        movement.onMoving -= AddPointInTime;
    }

    public override void ReverseTime()
    {
        if(pointsInTime.Count > 0)
        {
            transform.position = pointsInTime[pointsInTime.Count - 1].position;
            transform.rotation = pointsInTime[pointsInTime.Count - 1].rotation;

            pointsInTime.RemoveAt(pointsInTime.Count - 1);
        }
    }

    public void AddPointInTime()
    {
        pointsInTime.Add(new PlayerPointInTime(transform.position, transform.rotation));
    }
}
