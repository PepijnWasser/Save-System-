﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimedOjbectManager : MonoBehaviour
{
    List<GameObject> timedObjectList = new List<GameObject>();

    void Start()
    {
        GameObject[] objectsWithTag = GameObject.FindGameObjectsWithTag("timedObject");
        foreach(GameObject obj in objectsWithTag)
        {
            timedObjectList.Add(obj);
        }
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            foreach (GameObject obj in timedObjectList)
            {
                obj.GetComponent<TimedObject>().ReverseTime();
            }
        }
    }
}
