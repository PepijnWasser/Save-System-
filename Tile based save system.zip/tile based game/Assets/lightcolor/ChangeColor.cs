﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeColor : MonoBehaviour
{
    public delegate void colorEvent();
    public static event colorEvent onChangingColor;

    private void Start()
    {
        movement.onMoving += ChangeLightColor;
    }

    private void OnDestroy()
    {
        movement.onMoving -= ChangeLightColor;
    }


    public void ChangeLightColor()
    {
        onChangingColor?.Invoke();
        GetComponent<Renderer>().material.color = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
    }
}
