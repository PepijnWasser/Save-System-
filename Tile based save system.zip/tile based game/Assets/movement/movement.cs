﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movement : MonoBehaviour
{
    bool moving;
    Vector3 startPosition;
    Vector3 endPosition;
    public float speed = 0.2f;
    public int lBound, rBound, uBound, bBound;


    public delegate void movingEvent();
    public static event movingEvent onMoving;

    // Update is called once per frame
    void Update()
    {
        if (moving == false)
        {
            if (Input.GetKey(KeyCode.W))
            {
                StartCoroutine(MovePlayer(Vector3.up));
                transform.rotation = Quaternion.Euler(0, 0, 0);
            }
            else if (Input.GetKey(KeyCode.A))
            {
                StartCoroutine(MovePlayer(Vector3.left));
                transform.rotation = Quaternion.Euler(0, 0, 90);
            }
            else if (Input.GetKey(KeyCode.S))
            {
                StartCoroutine(MovePlayer(Vector3.down));
                transform.rotation = Quaternion.Euler(0, 0, 180);
            }
            else if (Input.GetKey(KeyCode.D))
            {
                StartCoroutine(MovePlayer(Vector3.right));
                transform.rotation = Quaternion.Euler(0, 0, 270);
            }
        }
     
    }

    private IEnumerator MovePlayer(Vector3 direction)
    {
        if (CheckValidMovement(direction))
        {
            moving = true;

            float elapsedTime = 0;
            startPosition = transform.position;
            endPosition = startPosition + direction;

            onMoving?.Invoke();

            while (elapsedTime < speed)
            {
                transform.position = Vector3.Lerp(startPosition, endPosition, elapsedTime / speed);
                elapsedTime += Time.deltaTime;
                yield return null;
            }

            transform.position = endPosition;


            moving = false;
        } 
    }

    bool CheckValidMovement(Vector3 direction)
    {
        if (
            transform.position.x + direction.x > lBound && 
            transform.position.x + direction.x < rBound &&
            transform.position.y + direction.y < uBound &&
            transform.position.y + direction.y > bBound
          )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
